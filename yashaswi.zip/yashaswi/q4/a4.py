def render_sidebar(user_role):
    print(f"Logged in as: {user_role}")

    if user_role == "admin":
        visible_tabs = ["Dashboard", "Reports", "Salaries", "Employee Manager", "Help"]
    
    elif user_role == "staff":
        visible_tabs = ["Dashboard", "Reports", "Help"]
    
    elif user_role == "volunteer":
        visible_tabs = ["Dashboard", "Help"]
  
    else:
        visible_tabs = []

    # visible_tabs = ["Dashboard", "Reports", "Salaries", "Employee Manager", "Help"]

    print("Tabs visible:")
    for tab in visible_tabs:
        print("-", tab)

render_sidebar("staff")
