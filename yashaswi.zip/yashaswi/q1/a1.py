last_fetched = None 

def fetch_attendance_csv(user):
   
    folder_ids = {
        "NSI": "drive_folder_nsi",
        "BCH": "drive_folder_bch",
        "SSEV": "drive_folder_ssev"
    }
    global last_fetched

    if user in folder_ids:
        if last_fetched:           
            folder_id = folder_ids[user]  
        else:
            folder_id = folder_ids[user]            
            last_fetched = folder_id 
    else:
        folder_id = "default_invalid"
    
    print("User:", user)
    print("Fetched folder:", folder_id)
    return folder_id

fetch_attendance_csv("NSI")
fetch_attendance_csv("BCH")  
fetch_attendance_csv("SSEV") 
