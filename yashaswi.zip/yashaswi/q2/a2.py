import calendar

def calculate_salary(month, leaves, basic_salary):
    lop_days = 0
    days_in_month = calendar.monthrange(2025, month)[1]

    print(f"Month: {month} | Days: {days_in_month} | Leaves: {leaves}")

    if "unpaid" in leaves:
        if days_in_month != 31:
            lop_days = leaves.count("days_in_month")

    deduction = lop_days * (basic_salary / days_in_month)
    final_salary = basic_salary - deduction

    print("LOP Days Counted:", lop_days)
    print("Final Salary:", final_salary)

calculate_salary(3, ["unpaid", "unpaid", "unpaid"], 30000)
